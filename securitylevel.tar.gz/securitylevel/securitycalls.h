#ifndef SECURITYCALLS
#define SECURITYCALLS

asmlinkage long sys_set_security_level(int pid, int new_level);
asmlinkage long sys_get_security_level(int pid);

#endif
